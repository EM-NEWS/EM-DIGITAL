// import { Typography, makeStyles } from "@mui/material";

// const useStyles = makeStyles((theme) => ({
//     root: {
//         backgroundColor: '#f8f9fa', // Color de fondo del footer
//         padding: theme.spacing(2), // Espaciado interno
//         textAlign: 'center', // Alineación centrada
//         borderTop: '1px solid #ccc', // Borde superior delgada
//     },
//     logo: {
//         width: 20, // Ancho del logo de derechos reservados
//         verticalAlign: 'middle', // Alinear verticalmente con el texto
//         marginLeft: theme.spacing(1), // Espaciado a la izquierda del logo
//     },
// }));

// export const Footer = () => {
//     return (
//         <div className={useStyles.root}>
//             <Typography variant="body2" color="textSecondary">
//                 © {new Date().getFullYear()} Nombre del Blog. Todos los derechos reservados.
//             </Typography>
//         </div>
//     )
// }
